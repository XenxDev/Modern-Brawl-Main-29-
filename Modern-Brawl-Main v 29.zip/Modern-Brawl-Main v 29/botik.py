import discord
import os
import json
from discord.ext.commands import Bot
from discord.ext import commands
bot = commands.Bot(command_prefix = '*', intents = discord.Intents.all())
bot.remove_command('help')
os.chdir("/Database/Player/")
none = None
true = True
false = False
@bot.command()
async def привязка(ctx, token= OTA2NDUzNTk5NTE1NzE3NjMy.YYY2sw.f0X5--UUBqKdtghyMzyJaDZj2f8):
		if token == None:
			emb = discord.Embed(title= 'Пошел нахуй!',colour=discord.Color.red())
			emb.add_field(name= 'Укажите токен',value='пж')
			await ctx.reply(embed=emb)
		else:
			with open('players.json', 'r') as f:
				t = json.load(f)
			if not str(ctx.author.id) in t or t[str(ctx.author.id)]["token"] == 0:
				try:
					for element in os.scandir('./'):
						if element.name == token+'.db':
							t[str(ctx.author.id)] = {}
							t[str(ctx.author.id)]["token"] = token
							with open('players.json', 'w') as f:
								json.dump(t,f)
								emb = discord.Embed(title= 'Успешно!',colour=discord.Color.green())
								emb.add_field(name= 'Занес твой акк в бд, теперь напиши *check что бы узнать инфу о акке',value='Удачи!')
							await ctx.send(embed=emb)
				except:
					await ctx.reply('Такого чела нет в бд.')
			else:
				await ctx.reply('Да ты еблан, ты уже зареган.')
from tinydb import TinyDB, Query, database
query = Query()
@bot.command()
async def check(ctx):
	with open('players.json', 'r') as f:
		data = json.load(f)
	if not str(ctx.author.id) in data or data[str(ctx.author.id)]["token"] == 0:
		await ctx.reply('Еблан, ты не привязал акк.')
	token = data[str(ctx.author.id)]["token"]
	db = TinyDB(f"./"+ str(token) + ".db")
	user_data = db.search(query.token == token)
	if user_data:
		emb = discord.Embed(title= 'Ваш аккаунт!',colour=discord.Color.blue())
		emb.add_field(name= 'Никнейм:',value=user_data[0]["info"]["name"])
		emb.add_field(name= 'Low ID: ', value= user_data[0]["info"]["lowID"])
		emb.add_field(name= 'Победы в одиночном столкновении: ',value= user_data[0]["info"]["soloWins"])
		emb.add_field(name= 'Победы в парном столкновении: ',value= user_data[0]["info"]["duoWins"])
		emb.add_field(name= 'Победы 3 на 3: ',value= user_data[0]["info"]["3vs3Wins"])
		emb.add_field(name= 'Гемы: ',value= user_data[0]["info"]["gems"])
		emb.add_field(name= 'Старпоинты: ',value= user_data[0]["info"]["starpoints"])
		emb.add_field(name= 'Монеты: ',value= user_data[0]["info"]["gold"])
		emb.add_field(name= 'Остаток удвоителя жетонов: ',value= user_data[0]["info"]["tokensdoubler"])
		emb.add_field(name= 'Сколько жетонов можно заработать в друж. бою: ',value= user_data[0]["info"]["availableTokens"])
		brawlboxes = int(round(user_data[0]["info"]["brawlBoxes"]))/10
		emb.add_field(name= 'Обычных ящиков: ',value= str(brawlboxes))
		bigboxes = int(round(user_data[0]["info"]["bigBoxes"]))/10
		emb.add_field(name= 'Больших ящиков: ',value= str(bigboxes))
		await ctx.reply(embed=emb)
@bot.command()
async def выйти(ctx):
	with open('players.json', 'r') as f:
		leave = json.load(f)
	leave[str(ctx.author.id)]["token"] = 0
	with open('players.json', 'w') as f:
		json.dump(leave,f)
	emb = discord.Embed(title= 'Успешно!',colour=discord.Color.green())
	emb.add_field(name= 'Вышел из твоего акка.',value='Если надумаешь войти введи *привязка твой токен')
	await ctx.reply(embed=emb)
@bot.command()
@commands.is_owner()
async def off(ctx):
	await ctx.bot.logout()
@bot.command()
async def help(ctx):
	emb = discord.Embed(title= 'Команды бота!',colour=discord.Color.blue())
	emb.add_field(name= "*привязка ваш токен",value='Привязка вашего акка к боту')
	emb.add_field(name= "*check", value='Ваш аккаунт')
	emb.add_field(name= '*выйти',value='Выход из акка')
	await ctx.reply(embed=emb)
#@bot.command()
#async def give(ctx, resourse=None, amount=None, chel:discord.Member=None):
#	if not ctx.author.id == 654028920370495489 or ctx.author.id == 541954604074532912:
#		embed = discord.Embed(title= 'Выдача ресурсов!',colour=discord.Color.magenta())
#		embed.add_field(name= 'Вы не можете давать ресурсы!',value='эх')
#		await ctx.reply(embed=embed)
#	else:
#			if chel == None:
#				emb = discord.Embed(title= 'Пошел нахуй!',colour=discord.Color.red())
#				emb.add_field(name= 'Укажите чела!',value='пж')
#			else:
#				if resourse == 'gold':
#					with open('players.json', 'r') as f:
#						res = json.load(f)
#					if not str(ctx.author.id) in res:
#						await ctx.reply('ПРИВЯЖИ АКК')
#					elif not str(chel.id) in res:
#						await ctx.reply('У чела не привязан акк.')
#					else:
#						db = TinyDB(res[str(chel.id)]["token"]+'.db')
#						query = Query()
#						data = db.search(query.token == str(res[str(chel.id)]["token"]))
#						user_data = data[0]
#						user_data["info"]["gold"] = amount
#						db.update(user_data, query.token == str(res[str(chel.id)]["token"]))
#						emb = discord.Embed(title= 'Ресурсы!',colour=discord.Color.green())
#						emb.add_field(name= 'Успешно добавил ресурсов',value='ого')
#						await ctx.reply(embed=emb)
@bot.command()
async def vip(ctx):
	emb = discord.Embed(title= 'Информация о вип статусе!',colour=discord.Color.green())
	with open('players.json', 'r') as f:
		vip = json.load(f)
	if not str(ctx.author.id) in vip:
		await ctx.reply('Ты не привязал акк.')
	else:
		token = vip[str(ctx.author.id)]["token"]
		db = TinyDB(f"./"+ str(token) + ".db")
		user_data = db.search(query.token == token)
		if user_data:
			if user_data[0]["info"]["vip"] == 0:
				emb.add_field(name= 'У вас нет вип статуса!',value='Его можно будет преобрести у <@541954604074532912>')
			elif user_data[0]["info"]["vip"] == 1:
				emb.add_field(name= 'У вас есть вип статус!',value='Шок')
			else:
				emb.add_field(name= 'Ошибка чтения даных в бд',value=':(')
		await ctx.reply(embed=emb)
bot.run('ODY1OTE1NzYxNTAyNTg0ODUy.YPK85Q.MqL0EkftS1-wujiOV2m8lBOfxdI')