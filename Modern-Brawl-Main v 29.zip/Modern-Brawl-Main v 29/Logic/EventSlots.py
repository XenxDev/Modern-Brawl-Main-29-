import time

class EventSlots:
    Timer = 86999

    maps = [
        # Status = [3 = Nothing, 2 = Star Token, 1 = New Event]
        {
            'ID': 9,
            'Status': 1,
            'Ended': False,
            'Modifier': 4,
            'Tokens': 0
        },

        {
            'ID': 190,
            'Status': 1,
            'Ended': False,
            'Modifier': 1,
            'Tokens': 100
        },

        {
            'ID': 24,
            'Status': 1,
            'Ended': False,
            'Modifier': 0,
            'Tokens': 10
        },

        {
            'ID': 290,
            'Status': 1,
            'Ended': False,
            'Modifier': 0,
            'Tokens': 10
        },

        {
            'ID': 180,
            'Status': 1,
            'Ended': False,
            'Modifier': 0,
            'Tokens': 50
        },

        {
            'ID': 167,
            'Status': 1,
            'Ended': False,
            'Modifier': 0,
            'Tokens': 50
        },

        {
            'ID': 1,
            'Status': 1,
            'Ended': False,
            'Modifier': 2,
            'Tokens': 50
        }
        
    ]