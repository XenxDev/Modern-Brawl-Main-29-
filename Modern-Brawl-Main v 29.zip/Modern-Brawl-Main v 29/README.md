# goyan-brawl-v29
Brawl Stars 29 Mod Server



### Setup
You need to change host in libxeonscript.so 

### FAQ
Apk crashes, what to do?
##### Try to launch APK on emulators (nox, bluestack or VMos)
